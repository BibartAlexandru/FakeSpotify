package com.example.fakespotify;

public class DoneState extends State{
    DoneState() {
        super(StateType.DONE);
    }
}
