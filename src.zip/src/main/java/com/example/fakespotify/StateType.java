package com.example.fakespotify;

public enum StateType {
    PLAYING,
    PAUSED,
    WAITING,
    DONE,
    GENERATING,


}
