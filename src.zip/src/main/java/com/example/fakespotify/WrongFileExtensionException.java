package com.example.fakespotify;

public class WrongFileExtensionException extends Exception{
}
