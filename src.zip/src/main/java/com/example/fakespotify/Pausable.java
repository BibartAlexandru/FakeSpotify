package com.example.fakespotify;

public interface Pausable {
    public void Pause() ;
}
