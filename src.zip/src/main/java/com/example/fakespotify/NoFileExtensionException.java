package com.example.fakespotify;

public class NoFileExtensionException extends Exception{
}

