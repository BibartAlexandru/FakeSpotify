package com.example.fakespotify;

public class NoSongsInDatabaseException extends Exception{
}
