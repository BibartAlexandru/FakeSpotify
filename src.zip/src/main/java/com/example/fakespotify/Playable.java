package com.example.fakespotify;

public interface Playable {
    public void Play() ;
}
