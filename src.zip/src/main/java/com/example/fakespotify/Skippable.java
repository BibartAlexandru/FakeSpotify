package com.example.fakespotify;

public interface Skippable {
    public void Skip() ;
}

