package com.example.fakespotify;

public enum VolumeChange {
    INCREASE,
    DECREASE
}

